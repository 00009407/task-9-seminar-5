
colour_list =["Red" , "Green" , "White" , "Black"]

print(colour_list[0])
print(colour_list[-1])